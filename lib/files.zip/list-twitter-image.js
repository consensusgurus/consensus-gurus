import Image from './opengraph-image';
export const runtime = 'edge';
export const alt = 'Consensus Gurus list preview';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';
export default Image;

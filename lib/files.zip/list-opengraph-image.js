import { ImageResponse } from 'next/og';
import { LISTS } from '@/lib/data';

export const runtime = 'edge';
export const alt = 'Consensus Gurus list preview';
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

const COLORS = {
  cream: '#f4ede0',
  paper: '#ebe2d0',
  ink: '#1a1611',
  ember: '#c0392b',
  faded: '#7a6f5e',
};

export default async function Image({ params }) {
  const id = decodeURIComponent(params.id);
  const list = LISTS.find((l) => l.id === id);

  if (!list) {
    return new ImageResponse(
      (
        <div
          style={{
            width: '100%',
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: COLORS.cream,
            color: COLORS.ink,
            fontFamily: 'serif',
            fontSize: 72,
          }}
        >
          Consensus Gurus
        </div>
      ),
      size
    );
  }

  // Show the top 5 from the AI source for the preview
  const items = (list.sources?.ai?.items || list.vote?.items || []).slice(0, 5);

  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          background: COLORS.cream,
          color: COLORS.ink,
          padding: '52px 60px',
          display: 'flex',
          flexDirection: 'column',
          position: 'relative',
        }}
      >
        {/* Top masthead */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            borderBottom: `2px solid ${COLORS.ink}`,
            paddingBottom: 14,
            fontSize: 18,
            letterSpacing: 4,
            textTransform: 'uppercase',
            color: COLORS.ink,
            fontWeight: 600,
          }}
        >
          <span style={{ display: 'flex' }}>Consensus Gurus</span>
          <span style={{ display: 'flex', color: COLORS.faded, fontSize: 14 }}>
            consensusgurus.com
          </span>
        </div>

        {/* Category */}
        <div
          style={{
            display: 'flex',
            marginTop: 32,
            fontSize: 20,
            letterSpacing: 4,
            textTransform: 'uppercase',
            color: COLORS.ember,
            fontWeight: 700,
          }}
        >
          {list.category} · Top Ten
        </div>

        {/* Two-column layout: title on left, items on right */}
        <div
          style={{
            display: 'flex',
            flex: 1,
            marginTop: 18,
            gap: 56,
          }}
        >
          {/* Title column */}
          <div
            style={{
              flex: '0 0 580px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
            }}
          >
            <h1
              style={{
                fontFamily: 'serif',
                fontWeight: 900,
                fontSize: list.title.length > 24 ? 64 : 78,
                lineHeight: 0.94,
                letterSpacing: -2,
                margin: 0,
                color: COLORS.ink,
              }}
            >
              {list.title}
            </h1>
            <div
              style={{
                display: 'flex',
                fontStyle: 'italic',
                fontSize: 20,
                lineHeight: 1.35,
                color: COLORS.faded,
                paddingLeft: 12,
                borderLeft: `3px solid ${COLORS.ember}`,
                marginBottom: 12,
                fontFamily: 'serif',
              }}
            >
              {list.blurb.length > 140 ? list.blurb.slice(0, 137) + '...' : list.blurb}
            </div>
          </div>

          {/* Items column */}
          <div
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
            }}
          >
            {items.map((item, i) => (
              <div
                key={i}
                style={{
                  display: 'flex',
                  alignItems: 'baseline',
                  gap: 16,
                  padding: '7px 0',
                  borderBottom: i < items.length - 1 ? `1px solid ${COLORS.ink}` : 'none',
                }}
              >
                <span
                  style={{
                    fontFamily: 'serif',
                    fontWeight: 900,
                    fontSize: i === 0 ? 36 : 26,
                    color: i === 0 ? COLORS.ember : COLORS.ink,
                    minWidth: 44,
                    lineHeight: 1,
                  }}
                >
                  {String(i + 1).padStart(2, '0')}
                </span>
                <span
                  style={{
                    fontFamily: 'serif',
                    fontSize: i === 0 ? 26 : 22,
                    fontWeight: i === 0 ? 700 : 500,
                    lineHeight: 1.1,
                    color: COLORS.ink,
                    flex: 1,
                  }}
                >
                  {item.length > 36 ? item.slice(0, 34) + '...' : item}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            borderTop: `2px solid ${COLORS.ink}`,
            paddingTop: 12,
            fontSize: 14,
            letterSpacing: 3,
            textTransform: 'uppercase',
            color: COLORS.ink,
            fontWeight: 600,
          }}
        >
          <span style={{ display: 'flex' }}>Vote · Share · Debate</span>
          <span style={{ display: 'flex', color: COLORS.faded }}>Vol. I</span>
        </div>
      </div>
    ),
    size
  );
}

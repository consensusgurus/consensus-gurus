// ============================================================
// NEW LIST ENTRIES — paste these into the LISTS array in lib/data.js
// Place them wherever you like. Order in the array doesn't matter
// since the home page sorts by view count.
// ============================================================


// ============================================================
// FACTUAL LIST — mode: 'facts'
// No voting tab. Tile shows "Top of the list" instead of
// "Currently topping the votes".
// ============================================================
{
  id: 'top-grossing-films-2025',
  title: 'Top-Grossing Films of 2025',
  category: 'Movies · 2025',
  type: 'entertainment',
  linkType: 'imdb',
  mode: 'facts',
  blurb: 'Worldwide box office winners of 2025, ranked by global gross per Box Office Mojo.',
  defaultSource: 'ai',
  sources: {
    ai: {
      label: 'Box Office Mojo · Worldwide Gross',
      items: [
        'Ne Zha 2',
        'Zootopia 2',
        'Avatar: Fire and Ash',
        'Lilo & Stitch',
        'A Minecraft Movie',
        'Wicked: For Good',
        'Jurassic World Rebirth',
        'Mission: Impossible - The Final Reckoning',
        'The Fantastic Four: First Steps',
        'Superman',
      ],
    },
  },
},


// ============================================================
// VOTE-ONLY LIST — mode: 'votes'
// No source tab. Items seeded with a loose expert order;
// reader votes take over from there.
// ============================================================
{
  id: 'alani-nu-flavors',
  title: 'Alani Nu Energy Flavors',
  category: 'Drinks',
  type: 'food',
  linkType: 'amazon',
  mode: 'votes',
  blurb: 'Every Alani Nu energy flavor, ranked by you. Loose expert order to start, your votes take it from there.',
  defaultSource: 'ai',
  vote: {
    items: [
      "Witch's Brew",
      'Breezeberry',
      'Cosmic Stardust',
      'Hawaiian Shaved Ice',
      'Juicy Peach',
      'Mimosa',
      'Tropsicle',
      'Watermelon Wave',
      'Cherry Slush',
      'Munchies',
    ],
  },
},
